namespace LudoLib
{
    public enum StateOfPiece
    {
        InPlay,
        Home,
        Safe,
        Finished
    }
}