namespace LudoLib
{
    // Define the Colors enum
    public enum Colors
    {
        Red,
        Blue,
        Green,
        Yellow
    }

}