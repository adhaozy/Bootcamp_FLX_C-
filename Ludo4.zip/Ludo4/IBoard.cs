namespace LudoLib
{
    public interface IBoard
    {
    void SetSafeSquares();
    int[] GetSafeSquares();
    
    }
}