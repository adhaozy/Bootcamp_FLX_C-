﻿using Iqbal;
using System;

namespace ITD.OOP1.Ludo
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            // Start a new Ludo Game 
            // by making an instans of game class
            GameController Ludo = new GameController();
           
            // Initialize the array of Token objects
            
        }
    }
}
