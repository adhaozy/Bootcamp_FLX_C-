﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iqbal
{
    public enum GameColor { Red = 0, Blue = 1, Green = 2, Yellow = 3};
}